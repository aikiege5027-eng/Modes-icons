KONE China · 电梯相关图标（最终整理版本，98 个）

kone-icons.css          iconfont 样式：引入后写 <i class="kone-icon kone-icon-sales"></i>
kone-icons.woff2 / .otf 字体文件，与 CSS 放在同一目录
kone-icons-sprite.svg   SVG Sprite：<svg><use href="kone-icons-sprite.svg#kone-icon-sales"/></svg>
demo.html               全部图标与 class 名，可搜中文含义；点 class 名复制

class 名是 icon 库原始名称，一个 class 可能对应多个中文含义，以 demo.html 里的列表为准。
大小用 font-size（16 / 32 / 48px 这类整数倍最清楚），颜色用 color。
